package pe.area51.clasefragments;

public interface ListadoInterface {

	public void onItemSelected(Nota nota);

}
