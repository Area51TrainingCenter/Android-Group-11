/** Automatically generated file. DO NOT MODIFY */
package pe.area51.threadclass;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}