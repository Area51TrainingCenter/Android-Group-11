package pe.area51.ejemploactivityresult;

public class ExampleActivity2 extends ExampleActivity {
}
