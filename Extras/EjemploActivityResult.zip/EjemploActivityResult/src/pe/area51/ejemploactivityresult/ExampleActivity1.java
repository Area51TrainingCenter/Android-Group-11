package pe.area51.ejemploactivityresult;

public class ExampleActivity1 extends ExampleActivity {
}
